﻿The code in this folder was taken from LiteNetLib, and is used under the MIT license.

Is is based on their source tree as of commit "e521d119bd3b811638ded63b6849d8eb7fca08f1".