## IlLine
  - changes the 0 at the end of stacktrace lines to the illine
  - if the exact line number is available in C# code it will print that one instead 
  
### updates
- 1.0.0
    release
# Installation
Drop IlLine.dll into `\BepInEx\plugins\`